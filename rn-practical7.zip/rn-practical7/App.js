import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Text } from 'react-native';

import { AppProvider } from './src/context/AppContext';
import UsersScreen from './src/screens/UsersScreen';
import UserDetailScreen from './src/screens/UserDetailScreen';
import PostsScreen from './src/screens/PostsScreen';
import TodosScreen from './src/screens/TodosScreen';

const Tab = createBottomTabNavigator();
const UsersStack = createNativeStackNavigator();

// Стек для Users (User List + User Detail)
function UsersStackNavigator() {
  return (
    <UsersStack.Navigator>
      <UsersStack.Screen
        name="UsersList"
        component={UsersScreen}
        options={{ title: 'Користувачі', headerStyle: { backgroundColor: '#fff' }, headerTitleStyle: { fontSize: 18, fontWeight: '700', color: '#1a1a2e' } }}
      />
      <UsersStack.Screen
        name="UserDetail"
        component={UserDetailScreen}
        options={({ route }) => ({
          title: route.params?.user?.name ?? 'Деталі',
          headerStyle: { backgroundColor: '#fff' },
          headerTitleStyle: { fontSize: 18, fontWeight: '700', color: '#1a1a2e' },
          headerBackTitle: 'Назад',
          headerTintColor: '#4f46e5',
        })}
      />
    </UsersStack.Navigator>
  );
}

export default function App() {
  return (
    <AppProvider>
      <NavigationContainer>
        <Tab.Navigator
          screenOptions={{
            tabBarActiveTintColor: '#4f46e5',
            tabBarInactiveTintColor: '#aaa',
            tabBarStyle: {
              backgroundColor: '#fff',
              borderTopWidth: 0.5,
              borderTopColor: '#e5e5e5',
              height: 60,
              paddingBottom: 8,
            },
            tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
            headerStyle: { backgroundColor: '#fff' },
            headerTitleStyle: { fontSize: 18, fontWeight: '700', color: '#1a1a2e' },
          }}
        >
          <Tab.Screen
            name="Users"
            component={UsersStackNavigator}
            options={{
              title: 'Користувачі',
              headerShown: false,
              tabBarIcon: ({ color, size }) => <Text style={{ fontSize: size, color }}>👥</Text>,
            }}
          />
          <Tab.Screen
            name="Posts"
            component={PostsScreen}
            options={{
              title: 'Пости',
              tabBarIcon: ({ color, size }) => <Text style={{ fontSize: size, color }}>📝</Text>,
              headerTitle: 'Пости',
            }}
          />
          <Tab.Screen
            name="Todos"
            component={TodosScreen}
            options={{
              title: 'Завдання',
              tabBarIcon: ({ color, size }) => <Text style={{ fontSize: size, color }}>✅</Text>,
              headerTitle: 'Завдання',
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </AppProvider>
  );
}
