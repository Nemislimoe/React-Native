import React, { useEffect, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
  ScrollView,
  ToastAndroid,
  Platform,
  Alert,
} from 'react-native';
import { useApp } from '../context/AppContext';

const FILTERS = [
  { key: 'all', label: 'Усі' },
  { key: 'pending', label: 'Очікують' },
  { key: 'done', label: 'Виконані' },
];

function showMessage(msg) {
  if (Platform.OS === 'android') {
    ToastAndroid.show(msg, ToastAndroid.SHORT);
  } else {
    Alert.alert('', msg, [{ text: 'OK' }], { cancelable: true });
  }
}

function TodoCard({ todo, onToggle }) {
  return (
    <TouchableOpacity
      style={styles.card}
      onPress={() => onToggle(todo.id)}
      activeOpacity={0.7}
    >
      <TouchableOpacity
        style={[styles.checkbox, todo.completed && styles.checkboxDone]}
        onPress={() => onToggle(todo.id)}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
      >
        {todo.completed && <Text style={styles.checkmark}>✓</Text>}
      </TouchableOpacity>

      <View style={styles.todoContent}>
        <Text
          style={[styles.todoTitle, todo.completed && styles.todoTitleDone]}
          numberOfLines={2}
        >
          {todo.title}
        </Text>
        <View style={styles.todoMeta}>
          <Text style={[
            styles.todoStatus,
            { color: todo.completed ? '#4f46e5' : '#f59e0b' }
          ]}>
            {todo.completed ? '✓ Виконано' : '○ Очікує'}
          </Text>
          <Text style={styles.todoId}>#{todo.id}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

function StatsBar({ todos }) {
  const done = todos.filter(t => t.completed).length;
  const total = todos.length;
  const percent = total > 0 ? Math.round((done / total) * 100) : 0;

  return (
    <View style={styles.statsBar}>
      <View style={styles.statsRow}>
        <Text style={styles.statsText}>
          Виконано: <Text style={styles.statsHighlight}>{done}</Text> з {total}
        </Text>
        <Text style={styles.statsPercent}>{percent}%</Text>
      </View>
      <View style={styles.progressTrack}>
        <View style={[styles.progressFill, { width: `${percent}%` }]} />
      </View>
    </View>
  );
}

export default function TodosScreen() {
  const { state, dispatch, fetchTodos, toggleTodo, getFilteredTodos } = useApp();
  const { todos, todosLoading, todosError, todoFilter } = state;

  useEffect(() => {
    if (todos.length === 0) fetchTodos();
  }, []);

  const filtered = getFilteredTodos();

  const handleToggle = useCallback(async (id) => {
    const todo = state.todos.find(t => t.id === id);
    if (!todo) return;
    await toggleTodo(id);
    const newStatus = !todo.completed;
    showMessage(newStatus ? '✓ Завдання виконано' : '○ Позначено як невиконане');
  }, [state.todos, toggleTodo]);

  const handleFilter = useCallback((key) => {
    dispatch({ type: 'SET_TODO_FILTER', payload: key });
  }, [dispatch]);

  if (todosError) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>Помилка: {todosError}</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={fetchTodos}>
          <Text style={styles.retryText}>Повторити</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Прогрес-бар */}
      {todos.length > 0 && <StatsBar todos={todos} />}

      {/* Фільтри */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filtersRow}
      >
        {FILTERS.map(f => (
          <TouchableOpacity
            key={f.key}
            style={[styles.chip, todoFilter === f.key && styles.chipActive]}
            onPress={() => handleFilter(f.key)}
            activeOpacity={0.7}
          >
            <Text style={[styles.chipText, todoFilter === f.key && styles.chipTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={item => String(item.id)}
        renderItem={({ item }) => <TodoCard todo={item} onToggle={handleToggle} />}
        refreshControl={
          <RefreshControl refreshing={todosLoading} onRefresh={fetchTodos} tintColor="#4f46e5" />
        }
        ListHeaderComponent={
          filtered.length > 0 && (
            <Text style={styles.sectionLabel}>
              {todoFilter === 'all'
                ? `Всього: ${filtered.length}`
                : todoFilter === 'done'
                  ? `Виконано: ${filtered.length}`
                  : `Очікують: ${filtered.length}`}
            </Text>
          )
        }
        ListEmptyComponent={
          todosLoading ? (
            <View style={styles.center}>
              <ActivityIndicator size="large" color="#4f46e5" />
              <Text style={styles.loadingText}>Завантаження завдань...</Text>
            </View>
          ) : (
            <View style={styles.center}>
              <Text style={styles.emptyIcon}>✅</Text>
              <Text style={styles.emptyText}>Немає завдань у цій категорії</Text>
            </View>
          )
        }
        contentContainerStyle={{ paddingBottom: 16 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 60 },
  statsBar: {
    backgroundColor: '#fff', padding: 14,
    borderBottomWidth: 0.5, borderBottomColor: '#e5e5e5',
  },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  statsText: { fontSize: 13, color: '#555' },
  statsHighlight: { fontWeight: '700', color: '#4f46e5' },
  statsPercent: { fontSize: 13, fontWeight: '700', color: '#4f46e5' },
  progressTrack: { height: 6, backgroundColor: '#e8e8f0', borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: '#4f46e5', borderRadius: 3 },
  filtersRow: { paddingHorizontal: 12, paddingVertical: 10, gap: 6 },
  chip: {
    paddingHorizontal: 14, paddingVertical: 5,
    borderRadius: 20, borderWidth: 1.5, borderColor: '#e5e5e5', backgroundColor: '#fff',
  },
  chipActive: { backgroundColor: '#4f46e5', borderColor: '#4f46e5' },
  chipText: { fontSize: 12, fontWeight: '600', color: '#555' },
  chipTextActive: { color: '#fff' },
  sectionLabel: {
    fontSize: 11, fontWeight: '600', color: '#888', textTransform: 'uppercase',
    letterSpacing: 0.5, paddingHorizontal: 16, paddingTop: 4, paddingBottom: 4,
  },
  card: {
    backgroundColor: '#fff', marginHorizontal: 12, marginTop: 8,
    borderRadius: 16, padding: 14, flexDirection: 'row', alignItems: 'flex-start',
    gap: 10, borderWidth: 0.5, borderColor: '#e8e8f0',
  },
  checkbox: {
    width: 24, height: 24, borderRadius: 12,
    borderWidth: 2, borderColor: '#ddd',
    alignItems: 'center', justifyContent: 'center', marginTop: 1,
  },
  checkboxDone: { backgroundColor: '#4f46e5', borderColor: '#4f46e5' },
  checkmark: { color: '#fff', fontSize: 13, fontWeight: '700' },
  todoContent: { flex: 1 },
  todoTitle: { fontSize: 14, color: '#1a1a2e', lineHeight: 20 },
  todoTitleDone: { textDecorationLine: 'line-through', color: '#aaa' },
  todoMeta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 4 },
  todoStatus: { fontSize: 11, fontWeight: '600' },
  todoId: { fontSize: 11, color: '#ccc' },
  loadingText: { marginTop: 12, color: '#888', fontSize: 14 },
  errorText: { color: '#dc2626', fontSize: 14, marginBottom: 16, textAlign: 'center' },
  retryBtn: { backgroundColor: '#4f46e5', paddingHorizontal: 24, paddingVertical: 10, borderRadius: 12 },
  retryText: { color: '#fff', fontWeight: '600', fontSize: 14 },
  emptyIcon: { fontSize: 40, marginBottom: 12 },
  emptyText: { fontSize: 15, color: '#888', fontWeight: '500' },
});
