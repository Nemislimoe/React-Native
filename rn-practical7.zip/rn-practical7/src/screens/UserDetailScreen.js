import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';

const COLORS = [
  '#4f46e5', '#0891b2', '#059669', '#d97706',
  '#dc2626', '#7c3aed', '#0284c7', '#16a34a',
];
const BG_COLORS = [
  '#eef2ff', '#e0f2fe', '#dcfce7', '#fef3c7',
  '#fee2e2', '#f3e8ff', '#e0f7ff', '#d1fae5',
];

function getInitials(name) {
  return name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

function InfoRow({ label, value }) {
  return (
    <View style={styles.row}>
      <Text style={styles.rowLabel}>{label}</Text>
      <Text style={styles.rowValue}>{value}</Text>
    </View>
  );
}

function Section({ title, children }) {
  return (
    <View style={styles.section}>
      {title && <Text style={styles.sectionTitle}>{title}</Text>}
      {children}
    </View>
  );
}

export default function UserDetailScreen({ route, navigation }) {
  const { user, index } = route.params;
  const color = COLORS[index % COLORS.length];
  const bg = BG_COLORS[index % BG_COLORS.length];

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 32 }}>
      {/* Аватар */}
      <View style={styles.avatarContainer}>
        <View style={[styles.avatarBig, { backgroundColor: bg }]}>
          <Text style={[styles.avatarText, { color }]}>{getInitials(user.name)}</Text>
        </View>
        <Text style={styles.name}>{user.name}</Text>
        <Text style={styles.username}>@{user.username}</Text>
      </View>

      {/* Контактна інформація */}
      <Section title="Контакти">
        <InfoRow label="📧  Email" value={user.email} />
        <InfoRow label="📞  Телефон" value={user.phone} />
        <InfoRow label="🌐  Сайт" value={user.website} />
      </Section>

      {/* Компанія */}
      <Section title="Компанія">
        <InfoRow label="🏢  Назва" value={user.company.name} />
        <InfoRow label="💬  Слоган" value={user.company.catchPhrase} />
        <InfoRow label="⚙️  Напрямок" value={user.company.bs} />
      </Section>

      {/* Адреса */}
      <Section title="Адреса">
        <InfoRow label="🏠  Вулиця" value={`${user.address.street}, ${user.address.suite}`} />
        <InfoRow label="🏙️  Місто" value={user.address.city} />
        <InfoRow label="📮  Індекс" value={user.address.zipcode} />
        <InfoRow
          label="📍  Координати"
          value={`${user.address.geo.lat}, ${user.address.geo.lng}`}
        />
      </Section>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  avatarContainer: { alignItems: 'center', paddingVertical: 24, backgroundColor: '#fff', borderBottomWidth: 0.5, borderBottomColor: '#e5e5e5' },
  avatarBig: {
    width: 80, height: 80, borderRadius: 40,
    alignItems: 'center', justifyContent: 'center', marginBottom: 12,
  },
  avatarText: { fontSize: 30, fontWeight: '700' },
  name: { fontSize: 22, fontWeight: '700', color: '#1a1a2e' },
  username: { fontSize: 14, color: '#888', marginTop: 4 },
  section: {
    backgroundColor: '#fff', margin: 12, borderRadius: 16,
    paddingHorizontal: 16, paddingVertical: 4,
    borderWidth: 0.5, borderColor: '#e8e8f0',
  },
  sectionTitle: {
    fontSize: 11, fontWeight: '600', color: '#888',
    textTransform: 'uppercase', letterSpacing: 0.5,
    paddingTop: 12, paddingBottom: 4,
  },
  row: {
    paddingVertical: 10,
    borderBottomWidth: 0.5, borderBottomColor: '#f0f0f5',
  },
  rowLabel: { fontSize: 12, color: '#888', marginBottom: 2 },
  rowValue: { fontSize: 14, fontWeight: '500', color: '#1a1a2e' },
});
