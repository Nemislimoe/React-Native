import React, { useEffect, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
  ScrollView,
} from 'react-native';
import { useApp } from '../context/AppContext';

const FILTERS = [
  { key: 'all', label: 'Усі' },
  { key: 'short', label: 'Короткі (< 100)' },
  { key: 'medium', label: 'Середні' },
  { key: 'long', label: 'Довгі (> 200)' },
];

function getLengthCategory(text) {
  if (text.length < 100) return 'short';
  if (text.length < 200) return 'medium';
  return 'long';
}

const BADGE_STYLES = {
  short: { bg: '#d1fae5', text: '#065f46', label: 'Короткий' },
  medium: { bg: '#fef3c7', text: '#92400e', label: 'Середній' },
  long: { bg: '#fee2e2', text: '#991b1b', label: 'Довгий' },
};

function PostCard({ post }) {
  const cat = getLengthCategory(post.body);
  const badge = BADGE_STYLES[cat];
  return (
    <View style={styles.card}>
      <Text style={styles.postTitle} numberOfLines={2}>{post.title}</Text>
      <Text style={styles.postBody} numberOfLines={3}>{post.body}</Text>
      <View style={styles.postMeta}>
        <View style={[styles.badge, { backgroundColor: badge.bg }]}>
          <Text style={[styles.badgeText, { color: badge.text }]}>{badge.label}</Text>
        </View>
        <Text style={styles.postId}>Post #{post.id}</Text>
        <Text style={styles.postLength}>{post.body.length} симв.</Text>
      </View>
    </View>
  );
}

export default function PostsScreen() {
  const { state, dispatch, fetchPosts, getFilteredPosts } = useApp();
  const { postsLoading, postsError, postSearch, postFilter, posts } = state;

  useEffect(() => {
    if (posts.length === 0) fetchPosts();
  }, []);

  const filtered = getFilteredPosts();

  const handleSearch = useCallback((text) => {
    dispatch({ type: 'SET_POST_SEARCH', payload: text });
  }, [dispatch]);

  const handleFilter = useCallback((key) => {
    dispatch({ type: 'SET_POST_FILTER', payload: key });
  }, [dispatch]);

  if (postsError) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>Помилка: {postsError}</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={fetchPosts}>
          <Text style={styles.retryText}>Повторити</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Пошукове поле */}
      <View style={styles.searchContainer}>
        <Text style={styles.searchIcon}>🔍</Text>
        <TextInput
          style={styles.searchInput}
          placeholder="Пошук за заголовком..."
          placeholderTextColor="#aaa"
          value={postSearch}
          onChangeText={handleSearch}
        />
        {postSearch.length > 0 && (
          <TouchableOpacity onPress={() => handleSearch('')}>
            <Text style={styles.clearBtn}>✕</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Фільтри */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filtersRow}
      >
        {FILTERS.map(f => (
          <TouchableOpacity
            key={f.key}
            style={[styles.chip, postFilter === f.key && styles.chipActive]}
            onPress={() => handleFilter(f.key)}
            activeOpacity={0.7}
          >
            <Text style={[styles.chipText, postFilter === f.key && styles.chipTextActive]}>
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={item => String(item.id)}
        renderItem={({ item }) => <PostCard post={item} />}
        refreshControl={
          <RefreshControl refreshing={postsLoading} onRefresh={fetchPosts} tintColor="#4f46e5" />
        }
        ListHeaderComponent={
          filtered.length > 0 && (
            <Text style={styles.sectionLabel}>
              Знайдено: {filtered.length} {posts.length > 0 ? `з ${posts.length}` : ''}
            </Text>
          )
        }
        ListEmptyComponent={
          postsLoading ? (
            <View style={styles.center}>
              <ActivityIndicator size="large" color="#4f46e5" />
              <Text style={styles.loadingText}>Завантаження постів...</Text>
            </View>
          ) : (
            <View style={styles.center}>
              <Text style={styles.emptyIcon}>🔎</Text>
              <Text style={styles.emptyText}>Нічого не знайдено</Text>
              <Text style={styles.emptyHint}>Спробуйте змінити пошук або фільтр</Text>
            </View>
          )
        }
        contentContainerStyle={{ paddingBottom: 16 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 60 },
  searchContainer: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: '#f0f0f5', borderRadius: 12,
    marginHorizontal: 12, marginTop: 12, paddingHorizontal: 12, paddingVertical: 8,
  },
  searchIcon: { fontSize: 16, marginRight: 8 },
  searchInput: { flex: 1, fontSize: 14, color: '#333' },
  clearBtn: { fontSize: 14, color: '#aaa', padding: 4 },
  filtersRow: { paddingHorizontal: 12, paddingVertical: 10, gap: 6 },
  chip: {
    paddingHorizontal: 12, paddingVertical: 5,
    borderRadius: 20, borderWidth: 1.5, borderColor: '#e5e5e5',
    backgroundColor: '#fff',
  },
  chipActive: { backgroundColor: '#4f46e5', borderColor: '#4f46e5' },
  chipText: { fontSize: 12, fontWeight: '600', color: '#555' },
  chipTextActive: { color: '#fff' },
  sectionLabel: {
    fontSize: 11, fontWeight: '600', color: '#888', textTransform: 'uppercase',
    letterSpacing: 0.5, paddingHorizontal: 16, paddingTop: 4, paddingBottom: 4,
  },
  card: {
    backgroundColor: '#fff', marginHorizontal: 12, marginTop: 8,
    borderRadius: 16, padding: 14,
    borderWidth: 0.5, borderColor: '#e8e8f0',
  },
  postTitle: { fontSize: 14, fontWeight: '600', color: '#1a1a2e', lineHeight: 20 },
  postBody: { fontSize: 12, color: '#888', marginTop: 6, lineHeight: 18 },
  postMeta: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8 },
  badge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 20 },
  badgeText: { fontSize: 10, fontWeight: '600' },
  postId: { fontSize: 11, color: '#aaa' },
  postLength: { fontSize: 11, color: '#aaa' },
  loadingText: { marginTop: 12, color: '#888', fontSize: 14 },
  errorText: { color: '#dc2626', fontSize: 14, marginBottom: 16, textAlign: 'center' },
  retryBtn: { backgroundColor: '#4f46e5', paddingHorizontal: 24, paddingVertical: 10, borderRadius: 12 },
  retryText: { color: '#fff', fontWeight: '600', fontSize: 14 },
  emptyIcon: { fontSize: 40, marginBottom: 12 },
  emptyText: { fontSize: 16, fontWeight: '600', color: '#555' },
  emptyHint: { fontSize: 13, color: '#aaa', marginTop: 4 },
});
