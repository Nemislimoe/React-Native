import React, { useEffect, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useApp } from '../context/AppContext';

const COLORS = [
  '#4f46e5', '#0891b2', '#059669', '#d97706',
  '#dc2626', '#7c3aed', '#0284c7', '#16a34a',
];
const BG_COLORS = [
  '#eef2ff', '#e0f2fe', '#dcfce7', '#fef3c7',
  '#fee2e2', '#f3e8ff', '#e0f7ff', '#d1fae5',
];

function getInitials(name) {
  return name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

function UserCard({ user, index, onPress }) {
  const color = COLORS[index % COLORS.length];
  const bg = BG_COLORS[index % BG_COLORS.length];

  return (
    <TouchableOpacity style={styles.card} onPress={() => onPress(user, index)} activeOpacity={0.7}>
      <View style={[styles.avatar, { backgroundColor: bg }]}>
        <Text style={[styles.avatarText, { color }]}>{getInitials(user.name)}</Text>
      </View>
      <View style={styles.userInfo}>
        <Text style={styles.userName}>{user.name}</Text>
        <Text style={styles.userEmail}>{user.email}</Text>
        <Text style={[styles.userCompany, { color }]}>{user.company.name}</Text>
      </View>
      <Text style={styles.chevron}>›</Text>
    </TouchableOpacity>
  );
}

export default function UsersScreen({ navigation }) {
  const { state, fetchUsers } = useApp();
  const { users, usersLoading, usersError } = state;

  useEffect(() => {
    if (users.length === 0) fetchUsers();
  }, []);

  const handlePress = useCallback((user, index) => {
    navigation.navigate('UserDetail', { user, index });
  }, [navigation]);

  if (usersError) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>Помилка: {usersError}</Text>
        <TouchableOpacity style={styles.retryBtn} onPress={fetchUsers}>
          <Text style={styles.retryText}>Повторити</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={users}
        keyExtractor={item => String(item.id)}
        renderItem={({ item, index }) => (
          <UserCard user={item} index={index} onPress={handlePress} />
        )}
        refreshControl={
          <RefreshControl refreshing={usersLoading} onRefresh={fetchUsers} tintColor="#4f46e5" />
        }
        ListHeaderComponent={
          users.length > 0 && (
            <Text style={styles.sectionLabel}>Всього: {users.length} користувачів</Text>
          )
        }
        ListEmptyComponent={
          usersLoading ? (
            <View style={styles.center}>
              <ActivityIndicator size="large" color="#4f46e5" />
              <Text style={styles.loadingText}>Завантаження...</Text>
            </View>
          ) : null
        }
        contentContainerStyle={{ paddingBottom: 16 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingTop: 80 },
  sectionLabel: {
    fontSize: 11, fontWeight: '600', color: '#888', textTransform: 'uppercase',
    letterSpacing: 0.5, paddingHorizontal: 16, paddingTop: 12, paddingBottom: 4,
  },
  card: {
    backgroundColor: '#fff', marginHorizontal: 12, marginTop: 8,
    borderRadius: 16, padding: 14, flexDirection: 'row', alignItems: 'center',
    borderWidth: 0.5, borderColor: '#e8e8f0',
  },
  avatar: {
    width: 44, height: 44, borderRadius: 22,
    alignItems: 'center', justifyContent: 'center', marginRight: 12,
  },
  avatarText: { fontSize: 16, fontWeight: '600' },
  userInfo: { flex: 1 },
  userName: { fontSize: 15, fontWeight: '600', color: '#1a1a2e' },
  userEmail: { fontSize: 12, color: '#888', marginTop: 2 },
  userCompany: { fontSize: 11, marginTop: 2, fontWeight: '500' },
  chevron: { fontSize: 22, color: '#ccc', marginLeft: 4 },
  loadingText: { marginTop: 12, color: '#888', fontSize: 14 },
  errorText: { color: '#dc2626', fontSize: 14, marginBottom: 16, textAlign: 'center' },
  retryBtn: {
    backgroundColor: '#4f46e5', paddingHorizontal: 24, paddingVertical: 10, borderRadius: 12,
  },
  retryText: { color: '#fff', fontWeight: '600', fontSize: 14 },
});
