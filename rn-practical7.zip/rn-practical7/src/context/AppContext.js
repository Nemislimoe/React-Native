import React, { createContext, useContext, useReducer, useCallback } from 'react';
import axios from 'axios';

const BASE_URL = 'https://jsonplaceholder.typicode.com';

const AppContext = createContext(null);

const initialState = {
  users: [],
  usersLoading: false,
  usersError: null,
  selectedUser: null,

  posts: [],
  postsLoading: false,
  postsError: null,
  postSearch: '',
  postFilter: 'all', // 'all' | 'short' | 'medium' | 'long'

  todos: [],
  todosLoading: false,
  todosError: null,
  todoFilter: 'all', // 'all' | 'pending' | 'done'
};

function reducer(state, action) {
  switch (action.type) {
    // Users
    case 'USERS_LOADING':
      return { ...state, usersLoading: true, usersError: null };
    case 'USERS_SUCCESS':
      return { ...state, usersLoading: false, users: action.payload };
    case 'USERS_ERROR':
      return { ...state, usersLoading: false, usersError: action.payload };
    case 'SET_SELECTED_USER':
      return { ...state, selectedUser: action.payload };

    // Posts
    case 'POSTS_LOADING':
      return { ...state, postsLoading: true, postsError: null };
    case 'POSTS_SUCCESS':
      return { ...state, postsLoading: false, posts: action.payload };
    case 'POSTS_ERROR':
      return { ...state, postsLoading: false, postsError: action.payload };
    case 'SET_POST_SEARCH':
      return { ...state, postSearch: action.payload };
    case 'SET_POST_FILTER':
      return { ...state, postFilter: action.payload };

    // Todos
    case 'TODOS_LOADING':
      return { ...state, todosLoading: true, todosError: null };
    case 'TODOS_SUCCESS':
      return { ...state, todosLoading: false, todos: action.payload };
    case 'TODOS_ERROR':
      return { ...state, todosLoading: false, todosError: action.payload };
    case 'TOGGLE_TODO':
      return {
        ...state,
        todos: state.todos.map(todo =>
          todo.id === action.payload
            ? { ...todo, completed: !todo.completed }
            : todo
        ),
      };
    case 'SET_TODO_FILTER':
      return { ...state, todoFilter: action.payload };

    default:
      return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const fetchUsers = useCallback(async () => {
    dispatch({ type: 'USERS_LOADING' });
    try {
      const { data } = await axios.get(`${BASE_URL}/users`);
      dispatch({ type: 'USERS_SUCCESS', payload: data });
    } catch (err) {
      dispatch({ type: 'USERS_ERROR', payload: err.message });
    }
  }, []);

  const fetchPosts = useCallback(async () => {
    dispatch({ type: 'POSTS_LOADING' });
    try {
      const { data } = await axios.get(`${BASE_URL}/posts`);
      dispatch({ type: 'POSTS_SUCCESS', payload: data });
    } catch (err) {
      dispatch({ type: 'POSTS_ERROR', payload: err.message });
    }
  }, []);

  const fetchTodos = useCallback(async () => {
    dispatch({ type: 'TODOS_LOADING' });
    try {
      const { data } = await axios.get(`${BASE_URL}/todos`, {
        params: { _limit: 30 },
      });
      dispatch({ type: 'TODOS_SUCCESS', payload: data });
    } catch (err) {
      dispatch({ type: 'TODOS_ERROR', payload: err.message });
    }
  }, []);

  const toggleTodo = useCallback(async (id) => {
    const todo = state.todos.find(t => t.id === id);
    if (!todo) return;
    // Оптимістичне оновлення
    dispatch({ type: 'TOGGLE_TODO', payload: id });
    try {
      await axios.patch(`${BASE_URL}/todos/${id}`, {
        completed: !todo.completed,
      });
    } catch (err) {
      // Повернення змін при помилці
      dispatch({ type: 'TOGGLE_TODO', payload: id });
    }
  }, [state.todos]);

  const getFilteredPosts = useCallback(() => {
    const { posts, postSearch, postFilter } = state;
    return posts.filter(post => {
      const matchSearch = post.title
        .toLowerCase()
        .includes(postSearch.toLowerCase());
      const len = post.body.length;
      const matchFilter =
        postFilter === 'all' ||
        (postFilter === 'short' && len < 100) ||
        (postFilter === 'medium' && len >= 100 && len < 200) ||
        (postFilter === 'long' && len >= 200);
      return matchSearch && matchFilter;
    });
  }, [state]);

  const getFilteredTodos = useCallback(() => {
    const { todos, todoFilter } = state;
    return todos.filter(todo => {
      if (todoFilter === 'done') return todo.completed;
      if (todoFilter === 'pending') return !todo.completed;
      return true;
    });
  }, [state]);

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        fetchUsers,
        fetchPosts,
        fetchTodos,
        toggleTodo,
        getFilteredPosts,
        getFilteredTodos,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
};
