/**
 * Завдання 4 — SQLite Нотатки з категоріями та пошуком
 *
 * Встановлення: expo install expo-sqlite
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList,
  StyleSheet, Alert, Modal, ScrollView,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import * as SQLite from 'expo-sqlite';

// ── Database layer ────────────────────────────────────────────────────────────
const db = SQLite.openDatabase('notes.db');

const DB = {
  init() {
    db.transaction(tx => {
      // Таблиця категорій
      tx.executeSql(`
        CREATE TABLE IF NOT EXISTS categories (
          id   INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT    NOT NULL UNIQUE,
          color TEXT   NOT NULL DEFAULT '#6C63FF'
        );
      `);
      // Таблиця нотаток
      tx.executeSql(`
        CREATE TABLE IF NOT EXISTS notes (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          title       TEXT NOT NULL,
          body        TEXT NOT NULL DEFAULT '',
          category_id INTEGER REFERENCES categories(id) ON DELETE SET NULL,
          created_at  TEXT NOT NULL,
          updated_at  TEXT NOT NULL
        );
      `);
      // Дефолтна категорія
      tx.executeSql(
        `INSERT OR IGNORE INTO categories (name, color) VALUES (?, ?), (?, ?), (?, ?);`,
        ['Особисте','#6C63FF','Робота','#10B981','Ідеї','#F59E0B']
      );
    });
  },

  getCategories(cb) {
    db.transaction(tx => {
      tx.executeSql(
        'SELECT c.*, COUNT(n.id) as note_count FROM categories c LEFT JOIN notes n ON n.category_id=c.id GROUP BY c.id ORDER BY c.name;',
        [], (_, { rows: { _array } }) => cb(_array)
      );
    });
  },

  addCategory(name, color, cb) {
    db.transaction(tx => {
      tx.executeSql(
        'INSERT INTO categories (name, color) VALUES (?, ?);',
        [name, color],
        (_, r) => cb(r.insertId),
        (_, e) => { Alert.alert('Помилка', e.message); return false; }
      );
    });
  },

  deleteCategory(id, cb) {
    db.transaction(tx => {
      tx.executeSql('DELETE FROM categories WHERE id = ?;', [id], () => cb());
    });
  },

  // Пошук через SQLite LIKE — серверний пошук без фільтрації на клієнті
  getNotes(categoryId, search, cb) {
    const whereClause = categoryId
      ? 'WHERE n.category_id = ? AND (n.title LIKE ? OR n.body LIKE ?)'
      : 'WHERE (n.title LIKE ? OR n.body LIKE ?)';
    const params = categoryId
      ? [categoryId, `%${search}%`, `%${search}%`]
      : [`%${search}%`, `%${search}%`];

    db.transaction(tx => {
      tx.executeSql(
        `SELECT n.*, c.name as cat_name, c.color as cat_color
         FROM notes n LEFT JOIN categories c ON c.id = n.category_id
         ${whereClause}
         ORDER BY n.updated_at DESC;`,
        params,
        (_, { rows: { _array } }) => cb(_array),
        (_, e) => { console.error(e); return false; }
      );
    });
  },

  addNote(title, body, categoryId, cb) {
    const now = new Date().toISOString();
    db.transaction(tx => {
      tx.executeSql(
        'INSERT INTO notes (title, body, category_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?);',
        [title, body, categoryId, now, now],
        (_, r) => cb(r.insertId),
        (_, e) => { Alert.alert('Помилка', e.message); return false; }
      );
    });
  },

  updateNote(id, title, body, categoryId, cb) {
    db.transaction(tx => {
      tx.executeSql(
        'UPDATE notes SET title=?, body=?, category_id=?, updated_at=? WHERE id=?;',
        [title, body, categoryId, new Date().toISOString(), id],
        () => cb(),
        (_, e) => { Alert.alert('Помилка', e.message); return false; }
      );
    });
  },

  deleteNote(id, cb) {
    db.transaction(tx => {
      tx.executeSql('DELETE FROM notes WHERE id=?;', [id], () => cb());
    });
  },
};

// ── Кольори для категорій ─────────────────────────────────────────────────────
const CAT_COLORS = ['#6C63FF','#10B981','#F59E0B','#EF4444','#3B82F6','#8B5CF6','#EC4899'];

// ── Компонент Картка нотатки ──────────────────────────────────────────────────
function NoteCard({ note, onPress, onDelete }) {
  const date = new Date(note.updated_at).toLocaleDateString('uk-UA', {
    day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit',
  });

  return (
    <TouchableOpacity style={styles.noteCard} onPress={() => onPress(note)}
      onLongPress={() => Alert.alert('Видалити нотатку?', note.title, [
        { text: 'Скасувати', style: 'cancel' },
        { text: 'Видалити', style: 'destructive', onPress: () => onDelete(note.id) },
      ])}
    >
      {note.cat_name && (
        <View style={[styles.catBadge, { backgroundColor: note.cat_color + '22' }]}>
          <View style={[styles.catDot, { backgroundColor: note.cat_color }]}/>
          <Text style={[styles.catBadgeText, { color: note.cat_color }]}>{note.cat_name}</Text>
        </View>
      )}
      <Text style={styles.noteTitle} numberOfLines={1}>{note.title}</Text>
      {note.body !== '' && (
        <Text style={styles.noteBody} numberOfLines={2}>{note.body}</Text>
      )}
      <Text style={styles.noteDate}>{date}</Text>
    </TouchableOpacity>
  );
}

// ── Модальне вікно редагування нотатки ───────────────────────────────────────
function NoteModal({ visible, note, categories, onSave, onClose }) {
  const [title,    setTitle]   = useState('');
  const [body,     setBody]    = useState('');
  const [catId,    setCatId]   = useState(null);

  useEffect(() => {
    if (note) {
      setTitle(note.title);
      setBody(note.body);
      setCatId(note.category_id);
    } else {
      setTitle(''); setBody(''); setCatId(categories[0]?.id ?? null);
    }
  }, [note, categories]);

  const handleSave = () => {
    if (!title.trim()) return;
    onSave({ id: note?.id, title: title.trim(), body, categoryId: catId });
    onClose();
  };

  return (
    <Modal visible={visible} animationType="slide">
      <KeyboardAvoidingView style={{ flex:1 }} behavior={Platform.OS==='ios'?'padding':undefined}>
        <View style={styles.modalHeader}>
          <TouchableOpacity onPress={onClose}>
            <Text style={styles.modalClose}>Скасувати</Text>
          </TouchableOpacity>
          <Text style={styles.modalTitle}>{note ? 'Редагування' : 'Нова нотатка'}</Text>
          <TouchableOpacity onPress={handleSave} disabled={!title.trim()}>
            <Text style={[styles.modalSaveBtn, !title.trim() && { opacity:.4 }]}>Зберегти</Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.modalBody} keyboardShouldPersistTaps="handled">
          {/* Категорія */}
          <Text style={styles.fieldLabel}>Категорія</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.catRow}>
            {categories.map(c => (
              <TouchableOpacity key={c.id}
                style={[styles.catChip, catId===c.id && { backgroundColor: c.color }]}
                onPress={() => setCatId(c.id)}
              >
                <Text style={[styles.catChipText, catId===c.id && { color:'#fff' }]}>{c.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Заголовок */}
          <Text style={styles.fieldLabel}>Заголовок *</Text>
          <TextInput
            style={styles.titleInput}
            value={title}
            onChangeText={setTitle}
            placeholder="Заголовок нотатки"
            placeholderTextColor="#bbb"
            fontSize={18}
            fontWeight="700"
          />

          {/* Текст */}
          <Text style={styles.fieldLabel}>Текст</Text>
          <TextInput
            style={styles.bodyInput}
            value={body}
            onChangeText={setBody}
            placeholder="Текст нотатки..."
            placeholderTextColor="#bbb"
            multiline
            textAlignVertical="top"
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ── Головний екран ────────────────────────────────────────────────────────────
export default function App() {
  const [notes,      setNotes]      = useState([]);
  const [categories, setCategories] = useState([]);
  const [search,     setSearch]     = useState('');
  const [activeCat,  setActiveCat]  = useState(null);
  const [editNote,   setEditNote]   = useState(null);
  const [modalOpen,  setModalOpen]  = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [catModal,   setCatModal]   = useState(false);
  const [selectedColor, setSelColor]= useState(CAT_COLORS[0]);

  useEffect(() => {
    DB.init();
    loadAll();
  }, []);

  // Перезавантажуємо нотатки при зміні фільтра або пошуку
  useEffect(() => { loadNotes(); }, [activeCat, search]);

  const loadAll = () => { loadCategories(); loadNotes(); };
  const loadCategories = () => DB.getCategories(setCategories);
  const loadNotes      = useCallback(() => {
    DB.getNotes(activeCat, search, setNotes);
  }, [activeCat, search]);

  const handleSaveNote = ({ id, title, body, categoryId }) => {
    if (id) {
      DB.updateNote(id, title, body, categoryId, loadAll);
    } else {
      DB.addNote(title, body, categoryId, loadAll);
    }
  };

  const handleDeleteNote = (id) => DB.deleteNote(id, loadAll);

  const handleAddCategory = () => {
    if (!newCatName.trim()) return;
    DB.addCategory(newCatName.trim(), selectedColor, () => {
      setNewCatName('');
      setCatModal(false);
      loadCategories();
    });
  };

  return (
    <View style={styles.safe}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerRow}>
          <Text style={styles.headerTitle}>📝 Нотатки</Text>
          <TouchableOpacity style={styles.addNoteBtn}
            onPress={() => { setEditNote(null); setModalOpen(true); }}>
            <Text style={styles.addNoteBtnText}>+ Нотатка</Text>
          </TouchableOpacity>
        </View>

        {/* SQLite LIKE пошук */}
        <View style={styles.searchBox}>
          <Text style={styles.searchIcon}>🔍</Text>
          <TextInput
            style={styles.searchInput}
            value={search}
            onChangeText={setSearch}
            placeholder="Пошук по SQLite LIKE..."
            placeholderTextColor="rgba(255,255,255,.6)"
          />
          {search !== '' && (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Text style={{ color:'rgba(255,255,255,.8)', fontSize:14 }}>✕</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Категорії */}
      <View style={styles.catsSection}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.catsList}>
          <TouchableOpacity
            style={[styles.catFilterBtn, activeCat===null && styles.catFilterBtnActive]}
            onPress={() => setActiveCat(null)}
          >
            <Text style={[styles.catFilterText, activeCat===null && { color:'#fff'}]}>
              Всі ({notes.length})
            </Text>
          </TouchableOpacity>
          {categories.map(c => (
            <TouchableOpacity key={c.id}
              style={[styles.catFilterBtn, activeCat===c.id && { backgroundColor:c.color }]}
              onPress={() => setActiveCat(activeCat===c.id ? null : c.id)}
              onLongPress={() => Alert.alert('Видалити категорію?',c.name,[
                {text:'Скасувати',style:'cancel'},
                {text:'Видалити',style:'destructive',onPress:()=>DB.deleteCategory(c.id,loadAll)},
              ])}
            >
              <Text style={[styles.catFilterText, activeCat===c.id && { color:'#fff'}]}>
                {c.name} ({c.note_count})
              </Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity style={styles.addCatBtn} onPress={() => setCatModal(true)}>
            <Text style={styles.addCatBtnText}>＋</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>

      {/* Нотатки */}
      <FlatList
        data={notes}
        keyExtractor={n => String(n.id)}
        numColumns={2}
        contentContainerStyle={styles.notesList}
        columnWrapperStyle={{ gap: 10 }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyEmoji}>📭</Text>
            <Text style={styles.emptyText}>
              {search ? 'Нічого не знайдено' : 'Немає нотаток'}
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={{ flex: 1 }}>
            <NoteCard
              note={item}
              onPress={n => { setEditNote(n); setModalOpen(true); }}
              onDelete={handleDeleteNote}
            />
          </View>
        )}
      />

      {/* Модальне вікно нотатки */}
      <NoteModal
        visible={modalOpen}
        note={editNote}
        categories={categories}
        onSave={handleSaveNote}
        onClose={() => setModalOpen(false)}
      />

      {/* Модальне вікно нової категорії */}
      <Modal visible={catModal} transparent animationType="fade">
        <View style={styles.catModalOverlay}>
          <View style={styles.catModalBox}>
            <Text style={styles.catModalTitle}>Нова категорія</Text>
            <TextInput
              style={styles.catModalInput}
              value={newCatName}
              onChangeText={setNewCatName}
              placeholder="Назва категорії"
              placeholderTextColor="#bbb"
              autoFocus
            />
            <View style={styles.colorPicker}>
              {CAT_COLORS.map(c => (
                <TouchableOpacity key={c}
                  style={[styles.colorDot, { backgroundColor:c },
                    selectedColor===c && styles.colorDotSelected]}
                  onPress={() => setSelColor(c)}
                />
              ))}
            </View>
            <View style={styles.catModalBtns}>
              <TouchableOpacity style={styles.catModalCancel} onPress={()=>setCatModal(false)}>
                <Text style={{ color:'#888', fontWeight:'600' }}>Скасувати</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.catModalSave, { backgroundColor: selectedColor }]}
                onPress={handleAddCategory}
              >
                <Text style={{ color:'#fff', fontWeight:'700' }}>Додати</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  safe: { flex:1, backgroundColor:'#F0F0F8' },

  header: { backgroundColor:'#6C63FF', padding:16, paddingTop:52, gap:10 },
  headerRow: { flexDirection:'row', alignItems:'center', justifyContent:'space-between' },
  headerTitle: { fontSize:22, fontWeight:'800', color:'#fff' },
  addNoteBtn: {
    backgroundColor:'rgba(255,255,255,.25)', borderRadius:10,
    paddingHorizontal:14, paddingVertical:7,
  },
  addNoteBtnText: { color:'#fff', fontWeight:'700', fontSize:14 },
  searchBox: {
    flexDirection:'row', alignItems:'center', gap:8,
    backgroundColor:'rgba(255,255,255,.2)', borderRadius:10, padding:8,
  },
  searchIcon:  { fontSize:14, color:'rgba(255,255,255,.8)' },
  searchInput: { flex:1, fontSize:13, color:'#fff', padding:0 },

  catsSection: { backgroundColor:'#fff', borderBottomWidth:0.5, borderBottomColor:'#eee' },
  catsList:    { padding:10, gap:8, flexDirection:'row' },
  catFilterBtn: {
    paddingHorizontal:12, paddingVertical:6, borderRadius:16,
    backgroundColor:'#f0f0f8', borderWidth:1, borderColor:'#e0e0e0',
  },
  catFilterBtnActive: { backgroundColor:'#6C63FF', borderColor:'#6C63FF' },
  catFilterText: { fontSize:12, fontWeight:'600', color:'#555' },
  addCatBtn: {
    width:30, height:30, borderRadius:15, borderWidth:1.5,
    borderColor:'#6C63FF', borderStyle:'dashed',
    alignItems:'center', justifyContent:'center',
  },
  addCatBtnText: { color:'#6C63FF', fontSize:18, fontWeight:'300', lineHeight:22 },

  notesList: { padding:10 },
  noteCard: {
    backgroundColor:'#fff', borderRadius:14, padding:12,
    marginBottom:10, gap:6,
    shadowColor:'#000', shadowOffset:{ width:0, height:1 },
    shadowOpacity:0.07, shadowRadius:4, elevation:2,
  },
  catBadge:     { flexDirection:'row', alignItems:'center', gap:4, alignSelf:'flex-start',
                  borderRadius:8, paddingHorizontal:7, paddingVertical:2 },
  catDot:       { width:6, height:6, borderRadius:3 },
  catBadgeText: { fontSize:9, fontWeight:'700' },
  noteTitle:    { fontSize:13, fontWeight:'700', color:'#1a1a2e' },
  noteBody:     { fontSize:11, color:'#888', lineHeight:16 },
  noteDate:     { fontSize:9, color:'#bbb', marginTop:2 },

  empty: { alignItems:'center', paddingTop:60, gap:8 },
  emptyEmoji: { fontSize:48 },
  emptyText:  { fontSize:15, color:'#888' },

  modalHeader: {
    flexDirection:'row', alignItems:'center', justifyContent:'space-between',
    padding:16, paddingTop:52, borderBottomWidth:0.5, borderBottomColor:'#eee',
    backgroundColor:'#fff',
  },
  modalClose:   { color:'#888', fontSize:14 },
  modalTitle:   { fontSize:16, fontWeight:'700', color:'#1a1a2e' },
  modalSaveBtn: { color:'#6C63FF', fontSize:14, fontWeight:'700' },
  modalBody:    { flex:1, backgroundColor:'#fff', padding:16 },
  fieldLabel:   { fontSize:11, fontWeight:'700', color:'#888',
                  textTransform:'uppercase', letterSpacing:0.5, marginBottom:6, marginTop:14 },
  catRow:       { flexGrow:0, marginBottom:4 },
  catChip: {
    paddingHorizontal:14, paddingVertical:7, borderRadius:20,
    backgroundColor:'#f0f0f8', borderWidth:1, borderColor:'#e0e0e0',
    marginRight:8,
  },
  catChipText: { fontSize:13, fontWeight:'600', color:'#555' },
  titleInput: {
    fontSize:22, fontWeight:'700', color:'#1a1a2e',
    borderBottomWidth:1.5, borderBottomColor:'#e0e0e0', paddingVertical:8,
  },
  bodyInput: {
    fontSize:15, color:'#1a1a2e', minHeight:180, lineHeight:24,
    borderWidth:1, borderColor:'#e0e0e0', borderRadius:12,
    padding:12, marginTop:4,
  },

  catModalOverlay: { flex:1, backgroundColor:'rgba(0,0,0,.45)', justifyContent:'center', padding:24 },
  catModalBox:     { backgroundColor:'#fff', borderRadius:20, padding:20, gap:14 },
  catModalTitle:   { fontSize:18, fontWeight:'700', color:'#1a1a2e' },
  catModalInput: {
    backgroundColor:'#f8f8f8', borderRadius:12, borderWidth:1,
    borderColor:'#e0e0e0', padding:12, fontSize:15, color:'#1a1a2e',
  },
  colorPicker: { flexDirection:'row', gap:10, flexWrap:'wrap' },
  colorDot:    { width:32, height:32, borderRadius:16 },
  colorDotSelected: { borderWidth:3, borderColor:'#1a1a2e' },
  catModalBtns: { flexDirection:'row', gap:10 },
  catModalCancel: {
    flex:1, borderRadius:12, borderWidth:1.5, borderColor:'#ddd',
    padding:12, alignItems:'center',
  },
  catModalSave: { flex:1, borderRadius:12, padding:12, alignItems:'center' },
});
