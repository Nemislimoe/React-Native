/**
 * Завдання 1 — AsyncStorage
 * Збереження імені користувача між сесіями
 *
 * Встановлення: expo install @react-native-async-storage/async-storage
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEY = '@user_name';

export default function App() {
  const [name, setName]       = useState('');
  const [saved, setSaved]     = useState('');
  const [loading, setLoading] = useState(true);

  // ── Зчитуємо ім'я при запуску ─────────────────────────────────────────────
  useEffect(() => {
    const loadName = async () => {
      try {
        const value = await AsyncStorage.getItem(STORAGE_KEY);
        if (value !== null) setSaved(value);
      } catch (e) {
        Alert.alert('Помилка читання', e.message);
      } finally {
        setLoading(false);
      }
    };
    loadName();
  }, []);

  // ── Зберігаємо ім'я ───────────────────────────────────────────────────────
  const handleSave = async () => {
    if (!name.trim()) return;
    try {
      await AsyncStorage.setItem(STORAGE_KEY, name.trim());
      setSaved(name.trim());
      setName('');
      Alert.alert('✅ Збережено', `Ім'я "${name.trim()}" збережено!`);
    } catch (e) {
      Alert.alert('Помилка збереження', e.message);
    }
  };

  // ── Видаляємо ім'я ────────────────────────────────────────────────────────
  const handleClear = async () => {
    try {
      await AsyncStorage.removeItem(STORAGE_KEY);
      setSaved('');
      Alert.alert('🗑 Видалено', 'Ім\'я видалено зі сховища');
    } catch (e) {
      Alert.alert('Помилка видалення', e.message);
    }
  };

  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color="#6C63FF" />
        <Text style={styles.loadingText}>Завантаження...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      style={styles.safe}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <View style={styles.container}>
        {/* Привітання */}
        <View style={styles.welcomeBox}>
          <Text style={styles.emoji}>👤</Text>
          {saved ? (
            <>
              <Text style={styles.welcome}>Вітаємо,</Text>
              <Text style={styles.savedName}>{saved}!</Text>
              <Text style={styles.hint}>Ім'я збережено в AsyncStorage</Text>
            </>
          ) : (
            <>
              <Text style={styles.welcome}>Як вас звати?</Text>
              <Text style={styles.hint}>Введіть ім'я — воно збережеться між запусками</Text>
            </>
          )}
        </View>

        {/* Форма */}
        <View style={styles.form}>
          <Text style={styles.label}>Ваше ім'я</Text>
          <TextInput
            style={styles.input}
            value={name}
            onChangeText={setName}
            placeholder="Наприклад: Олексій"
            placeholderTextColor="#bbb"
            returnKeyType="done"
            onSubmitEditing={handleSave}
          />

          <TouchableOpacity
            style={[styles.btn, !name.trim() && styles.btnDisabled]}
            onPress={handleSave}
            disabled={!name.trim()}
          >
            <Text style={styles.btnText}>💾 Зберегти</Text>
          </TouchableOpacity>

          {saved !== '' && (
            <TouchableOpacity style={styles.clearBtn} onPress={handleClear}>
              <Text style={styles.clearBtnText}>🗑 Видалити збережене ім'я</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Пояснення */}
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>ℹ️ Як це працює</Text>
          <Text style={styles.infoText}>
            {'• '}AsyncStorage.setItem(key, value) — зберігає рядок{'\n'}
            {'• '}AsyncStorage.getItem(key) — отримує значення{'\n'}
            {'• '}AsyncStorage.removeItem(key) — видаляє запис{'\n'}
            {'• '}useEffect(fn, []) — виконується при монтуванні
          </Text>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F0F0F8' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: '#888', fontSize: 14 },
  container: { flex: 1, padding: 24, justifyContent: 'center', gap: 20 },

  welcomeBox: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.07,
    shadowRadius: 8,
    elevation: 3,
  },
  emoji:     { fontSize: 48, marginBottom: 8 },
  welcome:   { fontSize: 18, fontWeight: '700', color: '#1a1a2e' },
  savedName: { fontSize: 28, fontWeight: '800', color: '#6C63FF', marginTop: 4 },
  hint:      { fontSize: 12, color: '#888', marginTop: 6, textAlign: 'center' },

  form: { gap: 10 },
  label: { fontSize: 13, fontWeight: '600', color: '#555' },
  input: {
    backgroundColor: '#fff',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: '#E0E0E0',
    padding: 14,
    fontSize: 16,
    color: '#1a1a2e',
  },
  btn: {
    backgroundColor: '#6C63FF',
    borderRadius: 12,
    padding: 15,
    alignItems: 'center',
  },
  btnDisabled: { backgroundColor: '#c4c4d8' },
  btnText:     { color: '#fff', fontWeight: '700', fontSize: 16 },
  clearBtn: {
    backgroundColor: '#fff',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: '#e74c3c',
    padding: 13,
    alignItems: 'center',
  },
  clearBtnText: { color: '#e74c3c', fontWeight: '700', fontSize: 14 },

  infoBox: {
    backgroundColor: '#eef',
    borderRadius: 12,
    padding: 14,
    borderLeftWidth: 4,
    borderLeftColor: '#6C63FF',
  },
  infoTitle: { fontSize: 13, fontWeight: '700', color: '#6C63FF', marginBottom: 6 },
  infoText:  { fontSize: 12, color: '#555', lineHeight: 20 },
});
