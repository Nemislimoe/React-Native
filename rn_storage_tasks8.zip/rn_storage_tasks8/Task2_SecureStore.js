/**
 * Завдання 2 — SecureStore
 * Збереження токена авторизації + автологін
 *
 * Встановлення: expo install expo-secure-store
 */

import React, { useState, useEffect, createContext, useContext } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, ActivityIndicator, Alert,
  KeyboardAvoidingView, Platform, ScrollView,
} from 'react-native';
import * as SecureStore from 'expo-secure-store';

const TOKEN_KEY = 'auth_token';
const USER_KEY  = 'auth_user';

// ── Auth Context ──────────────────────────────────────────────────────────────
const AuthContext = createContext(null);

function AuthProvider({ children }) {
  const [token,   setToken]   = useState(null);
  const [user,    setUser]    = useState(null);
  const [loading, setLoading] = useState(true); // перевірка при старті

  // ── Автологін: перевіряємо SecureStore при запуску ────────────────────────
  useEffect(() => {
    const checkToken = async () => {
      try {
        const storedToken = await SecureStore.getItemAsync(TOKEN_KEY);
        const storedUser  = await SecureStore.getItemAsync(USER_KEY);
        if (storedToken) {
          setToken(storedToken);
          setUser(storedUser ? JSON.parse(storedUser) : null);
        }
      } catch (e) {
        console.error('SecureStore read error:', e);
      } finally {
        setLoading(false);
      }
    };
    checkToken();
  }, []);

  // ── Вхід: зберігаємо токен у SecureStore ──────────────────────────────────
  const login = async (email, password) => {
    // Імітація API-запиту
    if (email === 'user@example.com' && password === 'password123') {
      const fakeToken = `token_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      const userData  = { id: 1, email, name: 'Тестовий Користувач' };
      try {
        // SecureStore шифрує дані — безпечніше за AsyncStorage
        await SecureStore.setItemAsync(TOKEN_KEY, fakeToken);
        await SecureStore.setItemAsync(USER_KEY, JSON.stringify(userData));
        setToken(fakeToken);
        setUser(userData);
        return { ok: true };
      } catch (e) {
        return { ok: false, error: e.message };
      }
    }
    return { ok: false, error: 'Невірний email або пароль' };
  };

  // ── Вихід: видаляємо токен ────────────────────────────────────────────────
  const logout = async () => {
    try {
      await SecureStore.deleteItemAsync(TOKEN_KEY);
      await SecureStore.deleteItemAsync(USER_KEY);
      setToken(null);
      setUser(null);
    } catch (e) {
      Alert.alert('Помилка', e.message);
    }
  };

  return (
    <AuthContext.Provider value={{ token, user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

const useAuth = () => useContext(AuthContext);

// ── Login Screen ───────────────────────────────────────────────────────────────
function LoginScreen() {
  const { login }                   = useAuth();
  const [email,    setEmail]        = useState('user@example.com');
  const [password, setPassword]     = useState('password123');
  const [showPass, setShowPass]     = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]           = useState('');

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      setError('Заповніть усі поля');
      return;
    }
    setSubmitting(true);
    setError('');
    const result = await login(email.trim(), password);
    setSubmitting(false);
    if (!result.ok) setError(result.error);
  };

  return (
    <KeyboardAvoidingView
      style={styles.safe}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.loginContainer}>
        <View style={styles.logoBox}>
          <Text style={styles.logoEmoji}>🔐</Text>
          <Text style={styles.logoTitle}>Вхід до системи</Text>
          <Text style={styles.logoSub}>Токен зберігається у SecureStore</Text>
        </View>

        <View style={styles.form}>
          <View style={styles.fieldGroup}>
            <Text style={styles.label}>Email</Text>
            <TextInput
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              placeholder="user@example.com"
              placeholderTextColor="#bbb"
            />
          </View>

          <View style={styles.fieldGroup}>
            <Text style={styles.label}>Пароль</Text>
            <View style={styles.passRow}>
              <TextInput
                style={[styles.input, { flex: 1, marginBottom: 0 }]}
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPass}
                placeholder="••••••••"
                placeholderTextColor="#bbb"
              />
              <TouchableOpacity
                style={styles.eyeBtn}
                onPress={() => setShowPass(v => !v)}
              >
                <Text style={styles.eyeIcon}>{showPass ? '🙈' : '👁'}</Text>
              </TouchableOpacity>
            </View>
          </View>

          {error !== '' && (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>⚠️ {error}</Text>
            </View>
          )}

          <TouchableOpacity
            style={[styles.btn, submitting && styles.btnDisabled]}
            onPress={handleLogin}
            disabled={submitting}
          >
            {submitting
              ? <ActivityIndicator color="#fff" />
              : <Text style={styles.btnText}>🔑 Увійти</Text>
            }
          </TouchableOpacity>
        </View>

        <View style={styles.hintBox}>
          <Text style={styles.hintTitle}>🧪 Тестові дані</Text>
          <Text style={styles.hintText}>Email: user@example.com{'\n'}Пароль: password123</Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

// ── Home Screen ────────────────────────────────────────────────────────────────
function HomeScreen() {
  const { user, token, logout } = useAuth();

  const handleLogout = () => {
    Alert.alert('Вийти?', 'Токен буде видалено зі SecureStore', [
      { text: 'Скасувати', style: 'cancel' },
      { text: 'Вийти', style: 'destructive', onPress: logout },
    ]);
  };

  return (
    <ScrollView style={styles.safe} contentContainerStyle={styles.homeContainer}>
      <View style={styles.welcomeCard}>
        <Text style={styles.welcomeEmoji}>✅</Text>
        <Text style={styles.welcomeTitle}>Ви увійшли!</Text>
        <Text style={styles.welcomeName}>{user?.name}</Text>
      </View>

      <View style={styles.tokenCard}>
        <Text style={styles.tokenLabel}>👤 Email</Text>
        <Text style={styles.tokenValue}>{user?.email}</Text>

        <Text style={[styles.tokenLabel, { marginTop: 12 }]}>🔑 Токен (SecureStore)</Text>
        <Text style={styles.tokenValue} numberOfLines={2}>{token}</Text>

        <View style={styles.secureBadge}>
          <Text style={styles.secureBadgeText}>
            🔒 Зашифровано Keychain / Keystore
          </Text>
        </View>
      </View>

      <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
        <Text style={styles.logoutBtnText}>🚪 Вийти</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

// ── Root ───────────────────────────────────────────────────────────────────────
function RootNavigator() {
  const { token, loading } = useAuth();

  if (loading) {
    return (
      <View style={styles.splashScreen}>
        <Text style={styles.splashEmoji}>🔐</Text>
        <ActivityIndicator size="large" color="#6C63FF" style={{ marginTop: 16 }} />
        <Text style={styles.splashText}>Перевірка авторизації...</Text>
      </View>
    );
  }

  return token ? <HomeScreen /> : <LoginScreen />;
}

export default function App() {
  return (
    <AuthProvider>
      <RootNavigator />
    </AuthProvider>
  );
}

// ── Styles ─────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F0F0F8' },

  splashScreen: {
    flex: 1, justifyContent: 'center', alignItems: 'center',
    backgroundColor: '#F0F0F8', gap: 8,
  },
  splashEmoji: { fontSize: 56 },
  splashText:  { color: '#888', fontSize: 14, marginTop: 8 },

  loginContainer: { flexGrow: 1, justifyContent: 'center', padding: 24, gap: 20 },
  logoBox: { alignItems: 'center', gap: 6 },
  logoEmoji: { fontSize: 56 },
  logoTitle: { fontSize: 24, fontWeight: '800', color: '#1a1a2e' },
  logoSub:   { fontSize: 12, color: '#888' },

  form: { gap: 14 },
  fieldGroup: { gap: 6 },
  label: { fontSize: 13, fontWeight: '600', color: '#555' },
  input: {
    backgroundColor: '#fff', borderRadius: 12,
    borderWidth: 1.5, borderColor: '#E0E0E0',
    padding: 14, fontSize: 15, color: '#1a1a2e',
  },
  passRow: { flexDirection: 'row', gap: 8, alignItems: 'center' },
  eyeBtn:  { padding: 12, backgroundColor: '#fff', borderRadius: 12,
             borderWidth: 1.5, borderColor: '#E0E0E0' },
  eyeIcon: { fontSize: 18 },

  errorBox: {
    backgroundColor: '#FEE', borderRadius: 10, padding: 12,
    borderLeftWidth: 4, borderLeftColor: '#e74c3c',
  },
  errorText: { color: '#c0392b', fontSize: 13, fontWeight: '500' },

  btn: {
    backgroundColor: '#6C63FF', borderRadius: 14,
    padding: 16, alignItems: 'center',
  },
  btnDisabled: { backgroundColor: '#c4c4d8' },
  btnText: { color: '#fff', fontWeight: '700', fontSize: 16 },

  hintBox: {
    backgroundColor: '#eef', borderRadius: 12, padding: 14,
    borderLeftWidth: 4, borderLeftColor: '#6C63FF',
  },
  hintTitle: { fontSize: 13, fontWeight: '700', color: '#6C63FF', marginBottom: 4 },
  hintText:  { fontSize: 12, color: '#555', lineHeight: 20 },

  homeContainer: { padding: 20, gap: 16 },
  welcomeCard: {
    backgroundColor: '#6C63FF', borderRadius: 20, padding: 28,
    alignItems: 'center', gap: 6,
  },
  welcomeEmoji: { fontSize: 44 },
  welcomeTitle: { fontSize: 18, fontWeight: '700', color: '#fff' },
  welcomeName:  { fontSize: 22, fontWeight: '800', color: '#fff' },

  tokenCard: {
    backgroundColor: '#fff', borderRadius: 16, padding: 16,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.07, shadowRadius: 8, elevation: 3,
  },
  tokenLabel: { fontSize: 11, fontWeight: '700', color: '#888', marginBottom: 4 },
  tokenValue: { fontSize: 13, color: '#1a1a2e', fontFamily: 'monospace' },
  secureBadge: {
    backgroundColor: '#e8f5e9', borderRadius: 8, padding: 8,
    marginTop: 14, alignItems: 'center',
  },
  secureBadgeText: { fontSize: 11, color: '#2e7d32', fontWeight: '600' },

  logoutBtn: {
    backgroundColor: '#fff', borderRadius: 14, borderWidth: 1.5,
    borderColor: '#e74c3c', padding: 15, alignItems: 'center',
  },
  logoutBtnText: { color: '#e74c3c', fontWeight: '700', fontSize: 16 },
});
