/**
 * Завдання 5 — Офлайн-чат з SQLite + синхронізація
 *
 * Встановлення:
 *   expo install expo-sqlite @react-native-community/netinfo
 *
 * Архітектура:
 *  ┌─────────────────────────────────────────────────────────┐
 *  │  Повідомлення зберігаються в SQLite (messages table)    │
 *  │  При відправці: status = 'pending'                      │
 *  │  При синхронізації: POST до API → status = 'synced'     │
 *  │  NetInfo стежить за мережею → auto-sync при connect     │
 *  └─────────────────────────────────────────────────────────┘
 */

import React, {
  useState, useEffect, useRef, useCallback, createContext, useContext,
} from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList,
  StyleSheet, Alert, ActivityIndicator, AppState,
} from 'react-native';
import * as SQLite from 'expo-sqlite';
import NetInfo from '@react-native-community/netinfo';

// ── Database ──────────────────────────────────────────────────────────────────
const db = SQLite.openDatabase('chat.db');

const DB = {
  init() {
    db.transaction(tx => {
      tx.executeSql(`
        CREATE TABLE IF NOT EXISTS messages (
          id          INTEGER PRIMARY KEY AUTOINCREMENT,
          server_id   INTEGER,                        -- id від сервера після sync
          room_id     INTEGER NOT NULL DEFAULT 1,
          author      TEXT    NOT NULL,
          body        TEXT    NOT NULL,
          created_at  TEXT    NOT NULL,
          status      TEXT    NOT NULL DEFAULT 'pending'
          -- pending | synced | failed
        );
      `);
      tx.executeSql(`
        CREATE TABLE IF NOT EXISTS sync_log (
          id         INTEGER PRIMARY KEY AUTOINCREMENT,
          synced_at  TEXT NOT NULL,
          count      INTEGER NOT NULL
        );
      `);
    });
  },

  getMessages(roomId, cb) {
    db.transaction(tx => {
      tx.executeSql(
        'SELECT * FROM messages WHERE room_id=? ORDER BY created_at ASC;',
        [roomId],
        (_, { rows: { _array } }) => cb(_array)
      );
    });
  },

  insertMessage(roomId, author, body, cb) {
    db.transaction(tx => {
      tx.executeSql(
        `INSERT INTO messages (room_id, author, body, created_at, status)
         VALUES (?, ?, ?, ?, 'pending');`,
        [roomId, author, body, new Date().toISOString()],
        (_, r) => cb(r.insertId),
        (_, e) => { console.error('insert error:', e); return false; }
      );
    });
  },

  // Отримуємо повідомлення зі статусом 'pending' для синхронізації
  getPendingMessages(cb) {
    db.transaction(tx => {
      tx.executeSql(
        "SELECT * FROM messages WHERE status='pending' ORDER BY created_at ASC;",
        [],
        (_, { rows: { _array } }) => cb(_array)
      );
    });
  },

  // Оновлюємо статус після успішної синхронізації
  markSynced(localId, serverId, cb) {
    db.transaction(tx => {
      tx.executeSql(
        "UPDATE messages SET status='synced', server_id=? WHERE id=?;",
        [serverId, localId],
        () => cb()
      );
    });
  },

  markFailed(localId, cb) {
    db.transaction(tx => {
      tx.executeSql(
        "UPDATE messages SET status='failed' WHERE id=?;",
        [localId],
        () => cb()
      );
    });
  },

  logSync(count, cb) {
    db.transaction(tx => {
      tx.executeSql(
        'INSERT INTO sync_log (synced_at, count) VALUES (?, ?);',
        [new Date().toISOString(), count],
        () => cb?.()
      );
    });
  },

  // Зберігаємо серверні повідомлення (отримані при sync)
  upsertServerMessage(msg, cb) {
    db.transaction(tx => {
      tx.executeSql(
        `INSERT OR IGNORE INTO messages
         (server_id, room_id, author, body, created_at, status)
         VALUES (?, ?, ?, ?, ?, 'synced');`,
        [msg.id, msg.roomId ?? 1, msg.author ?? msg.name, msg.body ?? msg.title, msg.createdAt ?? new Date().toISOString()],
        () => cb?.()
      );
    });
  },
};

// ── Sync Service ──────────────────────────────────────────────────────────────
const API_URL = 'https://jsonplaceholder.typicode.com';

const SyncService = {
  // Відправляємо pending повідомлення на сервер
  async pushPending(onProgress) {
    return new Promise(resolve => {
      DB.getPendingMessages(async (pending) => {
        if (pending.length === 0) { resolve({ synced: 0 }); return; }

        let synced = 0;
        for (const msg of pending) {
          try {
            // JSONPlaceholder: POST /posts (імітація API)
            const res = await fetch(`${API_URL}/posts`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                title:  msg.body,
                body:   msg.body,
                userId: 1,
              }),
            });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const data = await res.json();

            await new Promise(r => DB.markSynced(msg.id, data.id, r));
            synced++;
            onProgress?.(synced, pending.length);
          } catch (e) {
            await new Promise(r => DB.markFailed(msg.id, r));
            console.warn(`Sync failed for msg ${msg.id}:`, e.message);
          }
        }
        DB.logSync(synced);
        resolve({ synced, total: pending.length });
      });
    });
  },

  // Завантажуємо повідомлення з сервера (pull)
  async pullFromServer(roomId) {
    try {
      const res  = await fetch(`${API_URL}/posts?_limit=10`);
      const data = await res.json();
      for (const item of data) {
        await new Promise(r => DB.upsertServerMessage({
          id: item.id, roomId,
          author: `User ${item.userId}`,
          body: item.title,
          createdAt: new Date(Date.now() - item.id * 60000).toISOString(),
        }, r));
      }
      return data.length;
    } catch (e) {
      console.warn('Pull failed:', e.message);
      return 0;
    }
  },
};

// ── Chat Context ──────────────────────────────────────────────────────────────
const ChatContext = createContext(null);

function ChatProvider({ children }) {
  const [messages,   setMessages]   = useState([]);
  const [isOnline,   setIsOnline]   = useState(false);
  const [syncing,    setSyncing]    = useState(false);
  const [syncInfo,   setSyncInfo]   = useState(null);
  const [pendingCnt, setPendingCnt] = useState(0);
  const [initialized, setInit]      = useState(false);
  const roomId = 1;
  const currentUser = 'Ви';

  // ── Ініціалізація ────────────────────────────────────────────────────────
  useEffect(() => {
    DB.init();
    // Спочатку підтягуємо повідомлення з сервера (тільки один раз)
    SyncService.pullFromServer(roomId).then(() => {
      loadMessages();
      setInit(true);
    });
  }, []);

  // ── Стежимо за мережею ───────────────────────────────────────────────────
  useEffect(() => {
    const unsub = NetInfo.addEventListener(state => {
      const online = state.isConnected && state.isInternetReachable !== false;
      setIsOnline(online);
      // Автоматична синхронізація при підключенні
      if (online) syncMessages();
    });
    return () => unsub();
  }, []);

  const loadMessages = useCallback(() => {
    DB.getMessages(roomId, msgs => {
      setMessages(msgs);
      setPendingCnt(msgs.filter(m => m.status === 'pending').length);
    });
  }, []);

  const sendMessage = useCallback((body) => {
    if (!body.trim()) return;
    DB.insertMessage(roomId, currentUser, body.trim(), () => {
      loadMessages();
      // Якщо онлайн — синхронізуємо одразу
      if (isOnline) syncMessages();
    });
  }, [isOnline, loadMessages]);

  const syncMessages = useCallback(async () => {
    if (syncing) return;
    setSyncing(true);
    const result = await SyncService.pushPending();
    setSyncing(false);
    setSyncInfo(result);
    loadMessages();
    setTimeout(() => setSyncInfo(null), 3000);
  }, [syncing, loadMessages]);

  return (
    <ChatContext.Provider value={{
      messages, isOnline, syncing, syncInfo, pendingCnt,
      initialized, sendMessage, syncMessages, loadMessages,
    }}>
      {children}
    </ChatContext.Provider>
  );
}

const useChat = () => useContext(ChatContext);

// ── Message Bubble ────────────────────────────────────────────────────────────
function MessageBubble({ message }) {
  const isMe = message.author === 'Ви';
  const time  = new Date(message.created_at).toLocaleTimeString('uk-UA', {
    hour:'2-digit', minute:'2-digit',
  });

  const statusIcon = {
    pending: '🕐',
    synced:  '✓✓',
    failed:  '⚠️',
  }[message.status] || '•';

  const statusColor = {
    pending: '#aaa',
    synced:  '#4CAF50',
    failed:  '#e74c3c',
  }[message.status];

  return (
    <View style={[styles.bubbleRow, isMe && styles.bubbleRowMe]}>
      {!isMe && (
        <View style={styles.avatarSmall}>
          <Text style={styles.avatarSmallText}>{message.author[0]}</Text>
        </View>
      )}
      <View style={styles.bubbleWrap}>
        {!isMe && <Text style={styles.bubbleAuthor}>{message.author}</Text>}
        <View style={[styles.bubble, isMe ? styles.bubbleMe : styles.bubbleThem]}>
          <Text style={[styles.bubbleText, isMe && { color:'#fff' }]}>
            {message.body}
          </Text>
        </View>
        <View style={[styles.bubbleMeta, isMe && { alignSelf:'flex-end' }]}>
          <Text style={styles.bubbleTime}>{time}</Text>
          {isMe && (
            <Text style={[styles.bubbleStatus, { color: statusColor }]}>
              {statusIcon}
            </Text>
          )}
        </View>
      </View>
    </View>
  );
}

// ── Chat Screen ───────────────────────────────────────────────────────────────
function ChatScreen() {
  const {
    messages, isOnline, syncing, syncInfo, pendingCnt,
    initialized, sendMessage, syncMessages,
  } = useChat();

  const [input, setInput]  = useState('');
  const listRef            = useRef(null);

  // Скролл вниз при нових повідомленнях
  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [messages.length]);

  const handleSend = () => {
    if (!input.trim()) return;
    sendMessage(input);
    setInput('');
  };

  if (!initialized) {
    return (
      <View style={styles.splashScreen}>
        <ActivityIndicator size="large" color="#6C63FF" />
        <Text style={styles.splashText}>Завантаження чату...</Text>
      </View>
    );
  }

  return (
    <View style={styles.safe}>
      {/* Header */}
      <View style={styles.chatHeader}>
        <View style={styles.chatHeaderLeft}>
          <Text style={styles.chatTitle}>💬 Офлайн Чат</Text>
          <View style={styles.onlineBadge}>
            <View style={[styles.onlineDot, { backgroundColor: isOnline ? '#4CAF50' : '#aaa' }]}/>
            <Text style={styles.onlineText}>
              {isOnline ? 'Онлайн' : 'Офлайн'}
            </Text>
          </View>
        </View>
        <TouchableOpacity
          style={[styles.syncBtn, syncing && styles.syncBtnLoading]}
          onPress={syncMessages}
          disabled={syncing || !isOnline}
        >
          {syncing
            ? <ActivityIndicator size="small" color="#fff"/>
            : <Text style={styles.syncBtnText}>↑↓ Синх.</Text>
          }
        </TouchableOpacity>
      </View>

      {/* Статус синхронізації */}
      {syncInfo && (
        <View style={styles.syncBanner}>
          <Text style={styles.syncBannerText}>
            ✅ Синхронізовано: {syncInfo.synced}/{syncInfo.total ?? syncInfo.synced} повідомлень
          </Text>
        </View>
      )}
      {pendingCnt > 0 && !syncing && (
        <View style={[styles.syncBanner, { backgroundColor:'#FFF8E1' }]}>
          <Text style={[styles.syncBannerText, { color:'#F57F17'}]}>
            🕐 {pendingCnt} повідомлень очікують синхронізації
            {isOnline ? '' : ' (немає мережі)'}
          </Text>
        </View>
      )}

      {/* Повідомлення */}
      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={m => String(m.id)}
        contentContainerStyle={styles.messagesList}
        ListEmptyComponent={
          <View style={styles.emptyChat}>
            <Text style={styles.emptyChatEmoji}>💬</Text>
            <Text style={styles.emptyChatText}>Немає повідомлень{'\n'}Напишіть перше!</Text>
          </View>
        }
        renderItem={({ item }) => <MessageBubble message={item} />}
      />

      {/* Поле вводу */}
      <View style={styles.inputBar}>
        <TextInput
          style={styles.chatInput}
          value={input}
          onChangeText={setInput}
          placeholder="Повідомлення..."
          placeholderTextColor="#bbb"
          multiline
          maxLength={500}
          onSubmitEditing={handleSend}
          blurOnSubmit={false}
        />
        <TouchableOpacity
          style={[styles.sendBtn, !input.trim() && styles.sendBtnDisabled]}
          onPress={handleSend}
          disabled={!input.trim()}
        >
          <Text style={styles.sendBtnText}>▶</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ── App ───────────────────────────────────────────────────────────────────────
export default function App() {
  return (
    <ChatProvider>
      <ChatScreen />
    </ChatProvider>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  safe: { flex:1, backgroundColor:'#F0F0F8' },

  splashScreen: { flex:1, justifyContent:'center', alignItems:'center', gap:12 },
  splashText:   { color:'#888', fontSize:14 },

  chatHeader: {
    backgroundColor:'#6C63FF', paddingTop:52, paddingBottom:12,
    paddingHorizontal:16, flexDirection:'row',
    alignItems:'center', justifyContent:'space-between',
  },
  chatHeaderLeft: { gap:4 },
  chatTitle:      { fontSize:18, fontWeight:'800', color:'#fff' },
  onlineBadge:    { flexDirection:'row', alignItems:'center', gap:5 },
  onlineDot:      { width:7, height:7, borderRadius:4 },
  onlineText:     { fontSize:11, color:'rgba(255,255,255,.8)' },
  syncBtn: {
    backgroundColor:'rgba(255,255,255,.25)', borderRadius:10,
    paddingHorizontal:14, paddingVertical:7, minWidth:80, alignItems:'center',
  },
  syncBtnLoading: { backgroundColor:'rgba(255,255,255,.15)' },
  syncBtnText:    { color:'#fff', fontWeight:'700', fontSize:13 },

  syncBanner: {
    backgroundColor:'#E8F5E9', padding:8, paddingHorizontal:14,
    borderBottomWidth:0.5, borderBottomColor:'#C8E6C9',
  },
  syncBannerText: { fontSize:12, color:'#2E7D32', fontWeight:'500' },

  messagesList: { padding:12, paddingBottom:16, gap:4 },

  bubbleRow:   { flexDirection:'row', alignItems:'flex-end', gap:8, marginBottom:8 },
  bubbleRowMe: { flexDirection:'row-reverse' },
  avatarSmall: {
    width:28, height:28, borderRadius:14, backgroundColor:'#a78bfa',
    alignItems:'center', justifyContent:'center', flexShrink:0,
  },
  avatarSmallText: { color:'#fff', fontSize:12, fontWeight:'700' },

  bubbleWrap:   { maxWidth:'75%', gap:2 },
  bubbleAuthor: { fontSize:10, color:'#888', fontWeight:'600', marginLeft:4 },
  bubble: {
    borderRadius:16, paddingHorizontal:13, paddingVertical:9,
  },
  bubbleMe: {
    backgroundColor:'#6C63FF',
    borderBottomRightRadius:4,
  },
  bubbleThem: {
    backgroundColor:'#fff',
    borderBottomLeftRadius:4,
    shadowColor:'#000', shadowOffset:{ width:0, height:1 },
    shadowOpacity:0.06, shadowRadius:3, elevation:1,
  },
  bubbleText:   { fontSize:14, color:'#1a1a2e', lineHeight:20 },
  bubbleMeta:   { flexDirection:'row', gap:5, alignItems:'center', paddingHorizontal:4 },
  bubbleTime:   { fontSize:10, color:'#bbb' },
  bubbleStatus: { fontSize:11, fontWeight:'600' },

  emptyChat:      { flex:1, alignItems:'center', paddingTop:80, gap:10 },
  emptyChatEmoji: { fontSize:56 },
  emptyChatText:  { fontSize:15, color:'#888', textAlign:'center', lineHeight:22 },

  inputBar: {
    flexDirection:'row', gap:10, padding:10,
    backgroundColor:'#fff', borderTopWidth:0.5, borderTopColor:'#eee',
    alignItems:'flex-end',
  },
  chatInput: {
    flex:1, backgroundColor:'#f0f0f8', borderRadius:20, borderWidth:1,
    borderColor:'#e0e0e0', paddingHorizontal:14, paddingVertical:10,
    fontSize:14, color:'#1a1a2e', maxHeight:100,
  },
  sendBtn: {
    width:42, height:42, borderRadius:21, backgroundColor:'#6C63FF',
    alignItems:'center', justifyContent:'center',
  },
  sendBtnDisabled: { backgroundColor:'#c4c4d8' },
  sendBtnText:     { color:'#fff', fontSize:18, fontWeight:'700' },
});
