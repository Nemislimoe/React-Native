/**
 * Завдання 3 — SQLite TODO
 * Додавання, редагування, видалення завдань через SQLite
 *
 * Встановлення: expo install expo-sqlite
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, FlatList,
  StyleSheet, Alert, Modal, Animated, Platform,
  KeyboardAvoidingView,
} from 'react-native';
import * as SQLite from 'expo-sqlite';

// ── Ініціалізація БД ─────────────────────────────────────────────────────────
const db = SQLite.openDatabase('todos.db');

function initDB() {
  db.transaction(tx => {
    tx.executeSql(
      `CREATE TABLE IF NOT EXISTS todos (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        title     TEXT    NOT NULL,
        completed INTEGER NOT NULL DEFAULT 0,
        created_at TEXT   NOT NULL
      );`
    );
  });
}

// ── CRUD функції ──────────────────────────────────────────────────────────────
function fetchTodos(callback) {
  db.transaction(tx => {
    tx.executeSql(
      'SELECT * FROM todos ORDER BY created_at DESC;',
      [],
      (_, { rows: { _array } }) => callback(_array),
      (_, error) => { console.error('fetch error:', error); return false; }
    );
  });
}

function insertTodo(title, callback) {
  db.transaction(tx => {
    tx.executeSql(
      'INSERT INTO todos (title, completed, created_at) VALUES (?, 0, ?);',
      [title, new Date().toISOString()],
      (_, result) => callback(result.insertId),
      (_, error) => { console.error('insert error:', error); return false; }
    );
  });
}

function updateTodo(id, title, callback) {
  db.transaction(tx => {
    tx.executeSql(
      'UPDATE todos SET title = ? WHERE id = ?;',
      [title, id],
      () => callback(),
      (_, error) => { console.error('update error:', error); return false; }
    );
  });
}

function toggleTodo(id, completed, callback) {
  db.transaction(tx => {
    tx.executeSql(
      'UPDATE todos SET completed = ? WHERE id = ?;',
      [completed ? 0 : 1, id],
      () => callback(),
      (_, error) => { console.error('toggle error:', error); return false; }
    );
  });
}

function deleteTodo(id, callback) {
  db.transaction(tx => {
    tx.executeSql(
      'DELETE FROM todos WHERE id = ?;',
      [id],
      () => callback(),
      (_, error) => { console.error('delete error:', error); return false; }
    );
  });
}

// ── TodoItem компонент ────────────────────────────────────────────────────────
function TodoItem({ todo, onToggle, onEdit, onDelete }) {
  const fadeAnim = React.useRef(new Animated.Value(1)).current;

  const handleDelete = () => {
    Alert.alert('Видалити?', `"${todo.title}"`, [
      { text: 'Скасувати', style: 'cancel' },
      {
        text: 'Видалити', style: 'destructive',
        onPress: () => {
          Animated.timing(fadeAnim, { toValue: 0, duration: 250, useNativeDriver: true })
            .start(() => onDelete(todo.id));
        },
      },
    ]);
  };

  return (
    <Animated.View style={[styles.todoItem, { opacity: fadeAnim }]}>
      <TouchableOpacity
        style={[styles.checkbox, todo.completed && styles.checkboxDone]}
        onPress={() => onToggle(todo.id, todo.completed)}
      >
        {!!todo.completed && <Text style={styles.checkmark}>✓</Text>}
      </TouchableOpacity>

      <Text
        style={[styles.todoTitle, todo.completed && styles.todoTitleDone]}
        numberOfLines={2}
      >
        {todo.title}
      </Text>

      <View style={styles.todoActions}>
        <TouchableOpacity onPress={() => onEdit(todo)} style={styles.actionBtn}>
          <Text style={styles.actionBtnText}>✏️</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleDelete} style={styles.actionBtn}>
          <Text style={styles.actionBtnText}>🗑</Text>
        </TouchableOpacity>
      </View>
    </Animated.View>
  );
}

// ── Edit Modal ────────────────────────────────────────────────────────────────
function EditModal({ visible, todo, onSave, onClose }) {
  const [text, setText] = useState('');

  useEffect(() => {
    if (todo) setText(todo.title);
  }, [todo]);

  const handleSave = () => {
    if (!text.trim()) return;
    onSave(todo.id, text.trim());
    onClose();
  };

  return (
    <Modal visible={visible} transparent animationType="slide">
      <KeyboardAvoidingView
        style={styles.modalOverlay}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.modalBox}>
          <Text style={styles.modalTitle}>✏️ Редагувати завдання</Text>
          <TextInput
            style={styles.modalInput}
            value={text}
            onChangeText={setText}
            autoFocus
            multiline
            placeholder="Текст завдання..."
            placeholderTextColor="#bbb"
          />
          <View style={styles.modalBtns}>
            <TouchableOpacity style={styles.modalCancel} onPress={onClose}>
              <Text style={styles.modalCancelText}>Скасувати</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modalSave, !text.trim() && styles.btnDisabled]}
              onPress={handleSave}
              disabled={!text.trim()}
            >
              <Text style={styles.modalSaveText}>Зберегти</Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ── App ───────────────────────────────────────────────────────────────────────
export default function App() {
  const [todos,      setTodos]      = useState([]);
  const [input,      setInput]      = useState('');
  const [editTodo,   setEditTodo]   = useState(null);
  const [editVisible,setEditVisible]= useState(false);
  const [filter,     setFilter]     = useState('all'); // all | active | done

  useEffect(() => {
    initDB();
    loadTodos();
  }, []);

  const loadTodos = useCallback(() => {
    fetchTodos(data => setTodos(data));
  }, []);

  const handleAdd = () => {
    if (!input.trim()) return;
    insertTodo(input.trim(), () => {
      setInput('');
      loadTodos();
    });
  };

  const handleToggle = (id, completed) => {
    toggleTodo(id, completed, loadTodos);
  };

  const handleEdit = (todo) => {
    setEditTodo(todo);
    setEditVisible(true);
  };

  const handleSaveEdit = (id, title) => {
    updateTodo(id, title, loadTodos);
  };

  const handleDelete = (id) => {
    deleteTodo(id, loadTodos);
  };

  const visible = todos.filter(t =>
    filter === 'all'    ? true :
    filter === 'active' ? !t.completed :
    t.completed
  );

  const doneCount = todos.filter(t => t.completed).length;

  return (
    <View style={styles.safe}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>📋 SQLite Завдання</Text>
        <Text style={styles.headerSub}>
          {doneCount}/{todos.length} виконано · expo-sqlite
        </Text>
      </View>

      {/* Input */}
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Нове завдання..."
          placeholderTextColor="#bbb"
          returnKeyType="done"
          onSubmitEditing={handleAdd}
        />
        <TouchableOpacity
          style={[styles.addBtn, !input.trim() && styles.addBtnDisabled]}
          onPress={handleAdd}
          disabled={!input.trim()}
        >
          <Text style={styles.addBtnText}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Filter */}
      <View style={styles.filterRow}>
        {[['all','Всі'],['active','Активні'],['done','Виконані']].map(([key,label])=>(
          <TouchableOpacity
            key={key}
            style={[styles.filterBtn, filter===key && styles.filterBtnActive]}
            onPress={() => setFilter(key)}
          >
            <Text style={[styles.filterBtnText, filter===key && styles.filterBtnTextActive]}>
              {label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* List */}
      <FlatList
        data={visible}
        keyExtractor={item => String(item.id)}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyEmoji}>📭</Text>
            <Text style={styles.emptyText}>Немає завдань</Text>
          </View>
        }
        renderItem={({ item }) => (
          <TodoItem
            todo={item}
            onToggle={handleToggle}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        )}
      />

      {/* Edit Modal */}
      <EditModal
        visible={editVisible}
        todo={editTodo}
        onSave={handleSaveEdit}
        onClose={() => setEditVisible(false)}
      />
    </View>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F0F0F8' },

  header: {
    background: 'linear-gradient(135deg, #6C63FF, #a78bfa)',
    backgroundColor: '#6C63FF',
    padding: 20, paddingTop: 52,
  },
  headerTitle: { fontSize: 20, fontWeight: '800', color: '#fff' },
  headerSub:   { fontSize: 12, color: 'rgba(255,255,255,.75)', marginTop: 3 },

  inputRow: {
    flexDirection: 'row', gap: 8, padding: 12,
    backgroundColor: '#fff', borderBottomWidth: 0.5, borderBottomColor: '#eee',
  },
  input: {
    flex: 1, backgroundColor: '#f8f8f8', borderRadius: 10,
    borderWidth: 1, borderColor: '#e0e0e0',
    padding: 10, fontSize: 14, color: '#1a1a2e',
  },
  addBtn: {
    width: 42, height: 42, borderRadius: 21, backgroundColor: '#6C63FF',
    alignItems: 'center', justifyContent: 'center',
  },
  addBtnDisabled: { backgroundColor: '#c4c4d8' },
  addBtnText:     { color: '#fff', fontSize: 26, fontWeight: '300', lineHeight: 30 },

  filterRow: {
    flexDirection: 'row', padding: 8, gap: 6, backgroundColor: '#fff',
    borderBottomWidth: 0.5, borderBottomColor: '#eee',
  },
  filterBtn: {
    flex: 1, borderRadius: 8, paddingVertical: 6, alignItems: 'center',
    backgroundColor: '#f0f0f8',
  },
  filterBtnActive: { backgroundColor: '#6C63FF' },
  filterBtnText:   { fontSize: 12, fontWeight: '600', color: '#888' },
  filterBtnTextActive: { color: '#fff' },

  list: { padding: 12, gap: 8 },

  todoItem: {
    backgroundColor: '#fff', borderRadius: 12, padding: 12,
    flexDirection: 'row', alignItems: 'center', gap: 10,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06, shadowRadius: 4, elevation: 2,
  },
  checkbox: {
    width: 22, height: 22, borderRadius: 11, borderWidth: 2,
    borderColor: '#ccc', alignItems: 'center', justifyContent: 'center',
  },
  checkboxDone: { backgroundColor: '#6C63FF', borderColor: '#6C63FF' },
  checkmark:    { color: '#fff', fontSize: 12, fontWeight: '700' },
  todoTitle:    { flex: 1, fontSize: 14, color: '#1a1a2e', lineHeight: 20 },
  todoTitleDone:{ textDecorationLine: 'line-through', color: '#bbb' },
  todoActions:  { flexDirection: 'row', gap: 4 },
  actionBtn:    { padding: 4 },
  actionBtnText:{ fontSize: 16 },

  empty: { alignItems: 'center', paddingTop: 48, gap: 8 },
  emptyEmoji: { fontSize: 48 },
  emptyText:  { fontSize: 16, color: '#888' },

  modalOverlay: {
    flex: 1, backgroundColor: 'rgba(0,0,0,.45)',
    justifyContent: 'flex-end',
  },
  modalBox: {
    backgroundColor: '#fff', borderRadius: 20, padding: 20, gap: 14,
    marginHorizontal: 0,
  },
  modalTitle:  { fontSize: 17, fontWeight: '700', color: '#1a1a2e' },
  modalInput: {
    backgroundColor: '#f8f8f8', borderRadius: 12, borderWidth: 1,
    borderColor: '#e0e0e0', padding: 12, fontSize: 15, color: '#1a1a2e',
    minHeight: 80, textAlignVertical: 'top',
  },
  modalBtns:      { flexDirection: 'row', gap: 10 },
  modalCancel: {
    flex: 1, borderRadius: 12, borderWidth: 1.5, borderColor: '#ddd',
    padding: 13, alignItems: 'center',
  },
  modalCancelText: { color: '#888', fontWeight: '600' },
  modalSave: {
    flex: 1, backgroundColor: '#6C63FF', borderRadius: 12,
    padding: 13, alignItems: 'center',
  },
  modalSaveText: { color: '#fff', fontWeight: '700' },
  btnDisabled:   { backgroundColor: '#c4c4d8' },
});
